<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="medieval_tilesheet" tilewidth="64" tileheight="64" spacing="32" margin="32" tilecount="126" columns="18">
 <image source="../../../../../../../../../Assets/Kenney/Kenney Game Assets 2 version 22/2D assets/RTS Medieval (120 assets)/Tilesheet/medieval_tilesheet.png" width="1760" height="704"/>
</tileset>

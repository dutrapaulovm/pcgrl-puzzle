# -*- coding: utf-8 -*-
import os

RESOURCES_PATH = os.path.dirname(__file__) + "/resources/"

from pcgrl.smb import *
from pcgrl.smb.SMBLevelObjects import *
from pcgrl.smb.SMBGameProblem import SMBGameProblem
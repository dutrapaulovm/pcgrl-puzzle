# -*- coding: utf-8 -*-
import os

RESOURCES_COMBAT_PATH = os.path.dirname(__file__) + "/resources/combat"

from pcgrl.combat import *
from pcgrl.combat.CombatGameProblem import CombatGameProblem
from pcgrl.combat.CombatEnv import CombatEnv


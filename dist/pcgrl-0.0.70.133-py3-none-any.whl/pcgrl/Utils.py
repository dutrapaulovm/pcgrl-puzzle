# -*- coding: utf-8 -*-
from distutils.log import error
from gym.utils import seeding
from IPython.display import clear_output
from IPython import get_ipython

import pygame, sys
from pygame.locals import *
import collections, numpy
import math
import numpy as np
import time     
import random
import pandas as pd
from timeit import default_timer as timer
from datetime import timedelta
import heapq

# BFS approach:
from queue import Queue

import os

def noisy(val):
                    
    between_val = val / 2.0
    if (val < between_val):
        return int(round(np.random.uniform(val, between_val)))
    else:
        return int(round(np.random.uniform(between_val, val)))            

def sigmoid(x, a = 0.5):
    return a / (a + math.exp(-x))
                  
def to_power(x, n):
    res = 1
    for i in range(n):
        res *= x

    return res;    

def cum_mean(arr):
    cum_sum = np.cumsum(arr, axis=0)    
    for i in range(cum_sum.shape[0]):       
        if i == 0:
            continue
        cum_sum[i] =  cum_sum[i] / (i + 1)
    return cum_sum

def clear_console():
    if 'google.colab' in str(get_ipython()):
        clear_output()
    else:
        command = 'clear'
        if os.name in ('nt', 'dos'):  # If Machine is running on Windows, use cls
            command = 'cls'
        os.system(command)

def pdf(x, epsilon = 0.001):
    x = x + epsilon
    return x / np.sum(x)

def ecdf(data):    
    x = np.sort(data)
    n = x.size
    y = np.arange(1, n + 1) / n
    return (x , y)

#https://machinelearningmastery.com/divergence-between-probability-distributions/        
# calculate the kl divergence
def kl_divergence(p, q):   
    return sum(p[i] * np.log(p[i] / q[i]) for i in range(len(p)))   
 
# calculate the js divergence
def js_divergence(p, q, w = 0.5, epsilon: float = 1e-8):
        
    p = np.array(p)
    p = p.flatten()      
    
    q = np.array(q)
    q = q.flatten()
        
    p = p+epsilon
    q = q+epsilon
                
    m = w * (p + q)
            
    return (w * kl_divergence(p, q) + (1 - w) * kl_divergence(q, m))
    #return w * kl_divergence(p, m) + w * kl_divergence(q, p)

def decoded(state, max_cols):	
    
    col = state % max_cols
    a   = state // max_cols
    row = a % max_cols

    pos = (row, col)	
	
    return pos

def encoded(row, col, maxcols):
	return ( (maxcols * row) + col)

def encodedXY(x, y, maxcols, room_width, state_w, state_h):

	row   = 0
	col   = 0
	state = 0
	
	col = ((x) % room_width) / state_w
	
	row = ((y) % room_width) / state_h
		
	state = encoded( row, col, maxcols)
	
	return int(state)
	
def decodedXY(state, screen_width, state_width, state_height):
	
    max_cols = int(screen_width / state_width)

    col = state % max_cols
    a   = state // max_cols
    row = a % max_cols

    vec = pygame.Vector2()

    vec.y = int(row * state_height)
    vec.x = int(col * state_width)

    return vec

def neighbors(row, col, four_way=False):
    """Return indices of adjacent cells"""
    if four_way:
        return [
            (row - 1, col), (row, col + 1),
            (row + 1, col), (row, col - 1)]
    else:
        return [
            (row - 1, col), (row - 1, col + 1),
            (row, col + 1), (row + 1, col + 1),
            (row + 1, col), (row + 1, col - 1),
            (row, col - 1), (row - 1, col - 1)]
        
def manhattan_distance(xy1, xy2):
  "Returns the Manhattan distance between points xy1 and xy2"
  return abs( xy1[0] - xy2[0] ) + abs( xy1[1] - xy2[1] )

def flip_coin( p ):
  r = random.random()
  return r < p

# DFS approach:
def dfs(grid, i, j, old_color, new_color):
    n = len(grid)
    m = len(grid[0])
    if i < 0 or i >= n or j < 0 or j >= m or grid[i][j] != old_color:
        return
    else:
        grid[i][j] = new_color
        dfs(grid, i+1, j, old_color, new_color)
        dfs(grid, i-1, j, old_color, new_color)
        dfs(grid, i, j+1, old_color, new_color)
        dfs(grid, i, j-1, old_color, new_color)

def flood_fill(grid, i, j, new_color):
    old_color = grid[i][j]
    if old_color == new_color:
        return
    dfs(grid, i, j, old_color, new_color)     
 
def set_border_values(image, value):
    """Set edge values along all axes to a constant value.

    Parameters
    ----------
    image : ndarray
        The array to modify inplace.
    value : scalar
        The value to use. Should be compatible with `image`'s dtype.

    Examples
    --------
    >>> image = np.zeros((4, 5), dtype=int)
    >>> _set_border_values(image, 1)
    >>> image
    array([[1, 1, 1, 1, 1],
           [1, 0, 0, 0, 1],
           [1, 0, 0, 0, 1],
           [1, 1, 1, 1, 1]])
    """
    for axis in range(image.ndim):
        # Index first and last element in each dimension
        sl = (slice(None),) * axis + ((0, -1),) + (...,)
        image[sl] = value
        
def fast_pad(image, value, *, order="C"):
    """Pad an array on all axes by one with a value.

    Parameters
    ----------
    image : ndarray
        Image to pad.
    value : scalar
         The value to use. Should be compatible with `image`'s dtype.
    order : "C" or "F"
        Specify the memory layout of the padded image (C or Fortran style).

    Returns
    -------
    padded_image : ndarray
        The new image.

    Notes
    -----
    The output of this function is equivalent to::

        np.pad(image, 1, mode="constant", constant_values=value)

    Up to versions < 1.17 `numpy.pad` uses concatenation to create padded
    arrays while this method needs to only allocate and copy once.
    This can result in significant speed gains if `image` has a large number of
    dimensions.
    Thus this function may be safely removed once that version is the minimum
    required by scikit-image.

    Examples
    --------
    >>> _fast_pad(np.zeros((2, 3), dtype=int), 4)
    array([[4, 4, 4, 4, 4],
           [4, 0, 0, 0, 4],
           [4, 0, 0, 0, 4],
           [4, 4, 4, 4, 4]])
    """
    # Allocate padded image
    new_shape = np.array(image.shape) + 2
    new_image = np.empty(new_shape, dtype=image.dtype, order=order)

    # Copy old image into new space
    sl = (slice(1, -1),) * image.ndim
    new_image[sl] = image
    # and set the edge values
    set_border_values(new_image, value)

    return new_image


def flood_fill(grid, color_grid, row, col, color_index, passable_values):
    num_tiles = 0
    n = len(grid)
    m = len(grid[0])
    old_color = grid[row][col]
    if old_color == color_index:
        return 0    
    queue = Queue()
    queue.put((row, col))
    while not queue.empty():
        row, col = queue.get()                
        if row < 0 or row >= n or col < 0 or col >= m or color_grid[row][col] != -1 or grid[row][col] != old_color or grid[row][col] not in passable_values:
            continue
        else:
            num_tiles += 1                        
            color_grid[row][col] = color_index            
            grid[row][col]  = color_index
            queue.put((row + 1, col))
            queue.put((row - 1, col))
            queue.put((row, col + 1))
            queue.put((row, col - 1))
    
    return num_tiles

def entropy(p, b = 2, w = 1):
    """Calculate de entropy of an distribution

    Args:
        p (array): Distribution to calculate the entropy

    Returns:
        float: return the entropy
    """          
        
    _map = np.array(p)
    _map = list(_map.flatten())    
    _map = collections.Counter(_map)        
    _sum = sum(_map[e] for e in _map.keys())
    res = 0
    
    for e in _map.keys():
        p = _map[e] / _sum
        res -= w * (p*math.log(p, b))
    return w * res